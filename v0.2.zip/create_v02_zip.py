import os
import shutil
import zipfile

source_dir = r"d:\SourceBank\ai-vibecoding-2026"
temp_dir = os.path.join(source_dir, "v0.2_temp")
zip_path = os.path.join(source_dir, "v0.2.zip")

# Remove temp_dir if it already exists
if os.path.exists(temp_dir):
    shutil.rmtree(temp_dir)

os.makedirs(temp_dir)

# Copy everything except __pycache__, .git, temp_dir, and the zip file itself
for item in os.listdir(source_dir):
    if item in ["__pycache__", ".git", "v0.2_temp", "v0.2.zip", ".gemini", "node_modules"]:
        continue
    
    s = os.path.join(source_dir, item)
    d = os.path.join(temp_dir, item)
    if os.path.isdir(s):
        shutil.copytree(s, d, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    else:
        shutil.copy2(s, d)

# Clean the .env file in the temp directory
temp_env_path = os.path.join(temp_dir, ".env")
if os.path.exists(temp_env_path):
    with open(temp_env_path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    
    with open(temp_env_path, "w", encoding="utf-8") as f:
        for line in lines:
            if line.startswith("NH_APP_KEY="):
                f.write("NH_APP_KEY=YOUR_APP_KEY_HERE\n")
            elif line.startswith("NH_APP_SECRET="):
                f.write("NH_APP_SECRET=YOUR_APP_SECRET_HERE\n")
            else:
                f.write(line)

# Create the zip file
print(f"Creating {zip_path}...")
shutil.make_archive(os.path.join(source_dir, "v0.2"), 'zip', temp_dir)

# Remove the temporary directory
shutil.rmtree(temp_dir)
print("v0.2.zip creation complete and keys removed.")
