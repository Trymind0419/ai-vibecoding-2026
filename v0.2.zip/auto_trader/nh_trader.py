# -*- coding: utf-8 -*-
"""나무증권 API 연동 모듈"""
import logging
import random
import datetime
import os

# 시세 조회는 반드시 실서버(LIVE)를 사용하도록 강제 오버라이드
os.environ['NHPLUG_BASE_URL'] = 'https://api.nhplug.com:8443'

from auto_trader.config import settings

logger = logging.getLogger(__name__)

class NamuhAutoTrader:
    def __init__(self):
        self.is_connected = False
        self.use_real_api = False
        
        app_key = settings.NHPLUG_APP_KEY
        app_secret = settings.NHPLUG_APP_SECRET
        
        if not app_key or not app_secret or app_key == "YOUR_APP_KEY_HERE" or app_key == "":
            logger.warning("[NHPLUG] API 키가 설정되지 않아 시뮬레이션(안전) 모드로 작동합니다.")
            return

        try:
            import nhplug
            # 실제 nhplug 모듈 로드 성공
            self.use_real_api = True
            self.is_connected = True
            logger.info("[NHPLUG] 나무증권 API 연동 완료 (시세: LIVE)")
        except ImportError:
            logger.error("[NHPLUG] 'nhplug' 패키지가 설치되지 않았습니다. (pip install nhplug)")
        except Exception as e:
            logger.error(f"[NHPLUG] 연결 실패: {e}")
            
    def get_quotes(self, tickers: list):
        """다중 종목 실시간 시세 조회"""
        if self.use_real_api:
            import nhplug
            try:
                quotes = []
                for t in tickers:
                    try:
                        # 실제 나무증권 OpenAPI 호출
                        data = nhplug.call('/krstock/quote/v1/currentPrice', {'iem_cd': t["symbol"], 'market_cd': 'KRX'})
                        output = data.get('Output_0', {})
                        quotes.append({
                            "name": output.get("iem_nm", t["name"]).replace("*", ""),
                            "symbol": t["symbol"],
                            "price": int(output.get('stck_prpr', t["price"])),
                            "change": float(output.get('prdy_ctrt', 0.0))
                        })
                    except Exception as e:
                        # 특정 종목 조회 실패 시 임시값
                        quotes.append({"name": t["name"], "symbol": t["symbol"], "price": t["price"], "change": 0.0})
                return quotes
            except Exception as e:
                logger.error(f"실제 시세 조회 실패: {e}")
        
        # fallback
        results = []
        for t in tickers:
            results.append({
                "name": t["name"],
                "symbol": t["symbol"],
                "price": t["price"],
                "change": 0.0
            })
        return results

    def get_candles(self, symbol: str, limit: int = 100):
        """특정 종목의 캔들(OHLCV) 차트 데이터 조회 (Fallback)"""
        # (차트 기능은 Quote Board로 대체되었으므로 간단히 유지)
        return []

    # 주문 관련은 안전을 위해 시뮬레이션 유지
    def get_balance(self):
        return 10000000
    
    def get_positions(self):
        return {}
    
    def buy_market(self, symbol: str, qty: int):
        return True, "simulated_buy_id"
    
    def sell_market(self, symbol: str, qty: int):
        return True, "simulated_sell_id"
    
    def modify_order(self, order_id: str, new_price: int, new_qty: int):
        return True, f"modified_{order_id}"
    
    def cancel_order(self, order_id: str):
        return True, f"canceled_{order_id}"
