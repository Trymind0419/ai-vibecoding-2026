# -*- coding: utf-8 -*-
"""설정 관리 모듈"""
import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional

class Settings(BaseSettings):
    # 1. 기존 NHPLUG 증권사 API 설정
    TRADING_MODE: str = "PAPER"
    CONFIRM_REAL_TRADING: str = "false"
    NHPLUG_APP_KEY: str = ""
    NHPLUG_APP_SECRET: str = ""
    NHPLUG_BASE_URL: str = "https://moapi.nhplug.com:8443"
    NHPLUG_AUTH_URL: str = "https://api.nhplug.com:8443"
    NHPLUG_DEFAULT_ACCOUNT: Optional[str] = None
    NHPLUG_RATE_LIMIT: int = 4
    NHPLUG_TOKEN_CACHE: int = 1

    # 2. 추가된 봇(Bot) 매매 로직 설정
    TARGET_SYMBOLS: str = "005930"
    BREAKOUT_K: float = 0.5
    MAX_LOSS_PCT: float = 0.02
    PORT: int = 8000
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None

    # extra='ignore' 옵션으로 모르는 변수가 .env에 있어도 서버가 죽지 않게 방지합니다.
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
