# -*- coding: utf-8 -*-
"""전략 모듈"""
class VolatilityBreakoutStrategy:
    def __init__(self, k=0.5):
        self.k = k

    def get_target_price(self, current_price, high_price, low_price):
        range_diff = high_price - low_price
        target = current_price + (range_diff * self.k)
        return target

    def should_buy(self, current_price, target_price):
        return current_price >= target_price
